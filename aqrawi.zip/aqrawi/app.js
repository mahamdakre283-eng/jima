// app.js

// Application State
let categories = [];
let items = [];
let cart = [];
let selectedCategory = 'all';
let searchQuery = '';
let slideshowInterval = null;
let currentSlideIndex = 0;
let currentSettings = null;

// DOM Elements
const categoriesScroll = document.getElementById('categoriesScroll');
const menuGrid = document.getElementById('menuGrid');
const searchInput = document.getElementById('searchInput');
const searchClearBtn = document.getElementById('searchClearBtn');
const cartTrigger = document.getElementById('cartTrigger');
const cartOverlay = document.getElementById('cartOverlay');
const cartPanel = document.getElementById('cartPanel');
const closeCartBtn = document.getElementById('closeCartBtn');
const cartItemsList = document.getElementById('cartItemsList');
const totalPriceEl = document.getElementById('totalPrice');
const cartBadge = document.getElementById('cartBadge');
const checkoutBtn = document.getElementById('checkoutBtn');
const toastContainer = document.getElementById('toastContainer');

function updateDynamicHeader() {
  if (!currentSettings) return;
  const lang = getSelectedLanguage();
  
  // Update Logo
  const headerLogo = document.getElementById('headerLogo');
  if (headerLogo) {
    headerLogo.src = currentSettings.logo || 'images/logo.png';
  }

  // Update Restaurant Name
  const nameEl = document.querySelector('.restaurant-title');
  if (nameEl) {
    nameEl.textContent = currentSettings[`restaurant_name_${lang}`] || (translations[lang] && translations[lang].restaurant_name) || 'Akre Bistro';
  }

  // Update Restaurant Address
  const addressEl = document.querySelector('.restaurant-address span');
  if (addressEl) {
    addressEl.textContent = currentSettings[`address_${lang}`] || (translations[lang] && translations[lang].address) || 'Akre, 11 Aylol 2';
  }
}

// Register Event Listeners
function initMenu() {
  // Initialize subscriptions
  subscribeCategories((data) => {
    categories = data;
    renderCategories();
    renderMenu();
  });

  subscribeItems((data) => {
    items = data;
    renderMenu();
  });

  // Subscribe to dynamic settings (logo, backgrounds, restaurant name and address)
  subscribeSettings((settings) => {
    currentSettings = settings;
    updateDynamicHeader();

    const bgImages = [
      settings.bg_1 || 'images/bg.png',
      settings.bg_2 || '',
      settings.bg_3 || ''
    ].filter(url => url !== '');

    const heroSlides = document.getElementById('heroSlides');
    if (heroSlides && bgImages.length > 0) {
      heroSlides.innerHTML = bgImages.map((imgUrl, index) => {
        const activeClass = index === 0 ? 'active' : '';
        return `<div class="hero-slide ${activeClass}" style="background-image: url('${imgUrl}');"></div>`;
      }).join('');

      if (slideshowInterval) clearInterval(slideshowInterval);
      currentSlideIndex = 0;

      if (bgImages.length > 1) {
        slideshowInterval = setInterval(() => {
          const slides = heroSlides.querySelectorAll('.hero-slide');
          if (slides.length > 0) {
            slides[currentSlideIndex].classList.remove('active');
            currentSlideIndex = (currentSlideIndex + 1) % slides.length;
            slides[currentSlideIndex].classList.add('active');
          }
        }, 2000);
      }
    }
  });

  // Re-apply settings translations on language switch
  window.addEventListener('renderMenu', () => {
    updateDynamicHeader();
  });

  // Search logic
  searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value.toLowerCase().trim();
    
    // Auto-select "all" category if they start searching
    if (searchQuery) {
      selectedCategory = 'all';
      const cards = categoriesScroll.querySelectorAll('.category-card');
      cards.forEach(c => {
        if (c.getAttribute('data-id') === 'all') c.classList.add('active');
        else c.classList.remove('active');
      });
    }

    renderMenu();
  });

  searchClearBtn.addEventListener('click', () => {
    searchInput.value = '';
    searchQuery = '';
    renderMenu();
    searchInput.focus();
  });

  // Cart Drawer open/close
  cartTrigger.addEventListener('click', toggleCart);
  closeCartBtn.addEventListener('click', toggleCart);
  cartOverlay.addEventListener('click', (e) => {
    if (e.target === cartOverlay) toggleCart();
  });

  // Checkout WhatsApp logic
  checkoutBtn.addEventListener('click', handleCheckout);

  // Custom render event listener for language updates
  window.addEventListener('renderMenu', () => {
    renderCategories();
    renderMenu();
    renderCart();
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initMenu);
} else {
  initMenu();
}

// Toast System
function showToast(messageKey) {
  const lang = getSelectedLanguage();
  const message = translations[lang][messageKey] || messageKey;
  
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  toastContainer.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

// Render Categories Scroll Menu
function renderCategories() {
  const lang = getSelectedLanguage();
  
  // Create "All" category button
  const allActive = selectedCategory === 'all' ? 'active' : '';
  let html = `
    <div class="category-card ${allActive}" data-id="all">
      <div class="category-img" style="background: linear-gradient(135deg, #fbbf24, #d97706); display: flex; align-items: center; justify-content: center; color: #090d16; font-size: 1.5rem;">
        <i class="fa-solid fa-list-ul"></i>
      </div>
      <div class="category-name">${translations[lang].all_categories}</div>
    </div>
  `;

  // Render database categories
  categories.forEach(cat => {
    const isActive = selectedCategory === cat.id ? 'active' : '';
    const catName = cat[`name_${lang}`] || cat.name_en || '';
    const imgUrl = cat.image || 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80';
    
    html += `
      <div class="category-card ${isActive}" data-id="${cat.id}">
        <img src="${imgUrl}" alt="${catName}" class="category-img" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80'">
        <div class="category-name">${catName}</div>
      </div>
    `;
  });

  categoriesScroll.innerHTML = html;

  // Add click listeners to cards
  const cards = categoriesScroll.querySelectorAll('.category-card');
  cards.forEach(card => {
    card.addEventListener('click', () => {
      const catId = card.getAttribute('data-id');
      selectedCategory = catId;
      
      // Update active states visual
      cards.forEach(c => c.classList.remove('active'));
      card.classList.add('active');

      // Clear search query on category switch to keep navigation clean
      searchInput.value = '';
      searchQuery = '';
      
      renderMenu();
    });
  });
}

function normalizeSearchText(str) {
  if (!str) return '';
  return str
    .toLowerCase()
    .replace(/ك/g, 'ک')
    .replace(/ي/g, 'ی');
}

// Render Menu Cards Grid
function renderMenu() {
  const lang = getSelectedLanguage();
  
  // Filter items
  const filteredItems = items.filter(item => {
    // Category match
    const categoryMatch = selectedCategory === 'all' || item.category === selectedCategory;
    
    // Search match: check if query exists in name or description
    let searchMatch = true;
    if (searchQuery) {
      const name = normalizeSearchText(item[`name_${lang}`] || item.name_en || '');
      const desc = normalizeSearchText(item[`description_${lang}`] || item.description_en || '');
      const normalizedQuery = normalizeSearchText(searchQuery);
      searchMatch = name.includes(normalizedQuery) || desc.includes(normalizedQuery);
    }
    
    return categoryMatch && searchMatch;
  });

  // Display items
  if (filteredItems.length === 0) {
    menuGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-grey);">
        <i class="fa-solid fa-hourglass-empty" style="font-size: 2.5rem; margin-bottom: 15px; display: block; color: var(--border-color)"></i>
        <p>${lang === 'en' ? 'No food items found matching your filter.' : lang === 'ku' ? 'هیچ خوارنەک نەهاتە دیتن کو دگەل گەڕیانا تە بگونجیت.' : 'لم يتم العثور على وجبات تطابق بحثك.'}</p>
      </div>
    `;
    return;
  }

  menuGrid.innerHTML = filteredItems.map(item => {
    const name = item[`name_${lang}`] || item.name_en || '';
    const desc = item[`description_${lang}`] || item.description_en || '';
    const price = parseFloat(item.price || 0);
    const imgUrl = item.image || 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&q=80';
    const currency = translations[lang].currency;
    
    // Check if price should be formatted differently based on language/currency
    const formattedPrice = lang === 'en' ? `${currency}${price.toFixed(2)}` : `${price.toLocaleString()} ${currency}`;

    return `
      <div class="food-card" data-id="${item.id}">
        <div class="food-image-wrapper">
          <div class="food-price-tag">${formattedPrice}</div>
          <img src="${imgUrl}" alt="${name}" class="food-img" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&q=80'">
        </div>
        <div class="food-info">
          <h3 class="food-title">${name}</h3>
          <p class="food-desc">${desc}</p>
          <div class="food-footer">
            <div class="food-price-label">${formattedPrice}</div>
            <button class="add-btn" onclick="addToCart('${item.id}')">
              <i class="fa-solid fa-plus"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Cart System Functions

window.addToCart = (itemId) => {
  const item = items.find(i => i.id === itemId);
  if (!item) return;

  const existing = cart.find(c => c.item.id === itemId);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ item, quantity: 1 });
  }

  updateCartState();
  showToast('toast_added');
  
  // Trigger brief scale animation on cart button
  cartTrigger.classList.add('pop');
  setTimeout(() => cartTrigger.classList.remove('pop'), 300);
};

window.updateQty = (itemId, change) => {
  const cartItem = cart.find(c => c.item.id === itemId);
  if (!cartItem) return;

  cartItem.quantity += change;
  if (cartItem.quantity <= 0) {
    cart = cart.filter(c => c.item.id !== itemId);
    showToast('toast_removed');
  }

  updateCartState();
};

function updateCartState() {
  renderCart();
  
  // Count total quantity
  const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);
  cartBadge.textContent = totalQty;
  
  // Calculate total price
  const totalPrice = cart.reduce((sum, entry) => sum + (parseFloat(entry.item.price || 0) * entry.quantity), 0);
  const lang = getSelectedLanguage();
  const currency = translations[lang].currency;
  
  totalPriceEl.textContent = lang === 'en' ? `${currency}${totalPrice.toFixed(2)}` : `${totalPrice.toLocaleString()} ${currency}`;

  // Hide or show floating button based on items
  if (totalQty > 0) {
    cartTrigger.style.display = 'flex';
  } else {
    cartTrigger.style.display = 'none';
  }
}

function renderCart() {
  const lang = getSelectedLanguage();
  const currency = translations[lang].currency;

  if (cart.length === 0) {
    cartItemsList.innerHTML = `
      <div class="empty-cart-view">
        <i class="fa-solid fa-basket-shopping empty-cart-icon"></i>
        <p data-translate="cart_empty">${translations[lang].cart_empty}</p>
      </div>
    `;
    return;
  }

  cartItemsList.innerHTML = cart.map(entry => {
    const item = entry.item;
    const name = item[`name_${lang}`] || item.name_en || '';
    const itemPrice = parseFloat(item.price || 0);
    const itemTotal = itemPrice * entry.quantity;
    const imgUrl = item.image || 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80';
    
    const formattedPrice = lang === 'en' ? `${currency}${itemTotal.toFixed(2)}` : `${itemTotal.toLocaleString()} ${currency}`;

    return `
      <div class="cart-item">
        <img src="${imgUrl}" alt="${name}" class="cart-item-img" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80'">
        <div class="cart-item-details">
          <h4 class="cart-item-name">${name}</h4>
          <div class="cart-item-price">${formattedPrice}</div>
        </div>
        <div class="cart-item-controls">
          <button class="qty-btn" onclick="updateQty('${item.id}', -1)">-</button>
          <span class="qty-val">${entry.quantity}</span>
          <button class="qty-btn" onclick="updateQty('${item.id}', 1)">+</button>
        </div>
      </div>
    `;
  }).join('');
}

function toggleCart() {
  cartOverlay.classList.toggle('open');
}

// Order checkout message sent to restaurant via WhatsApp
function handleCheckout() {
  const lang = getSelectedLanguage();
  const currency = translations[lang].currency;
  
  if (cart.length === 0) return;

  // Akre Bistro WhatsApp Phone Number Template (User can change this inside their business code)
  const phoneNumber = "9647500000000"; // Default template
  
  let messageText = translations[lang].whatsapp_intro;
  
  cart.forEach(entry => {
    const itemName = entry.item[`name_${lang}`] || entry.item.name_en;
    const itemPrice = parseFloat(entry.item.price || 0);
    const lineTotal = itemPrice * entry.quantity;
    const formattedLinePrice = lang === 'en' ? `${currency}${lineTotal.toFixed(2)}` : `${lineTotal.toLocaleString()} ${currency}`;
    
    messageText += `• ${entry.quantity}x *${itemName}* - ${formattedLinePrice}\n`;
  });
  
  const totalPrice = cart.reduce((sum, entry) => sum + (parseFloat(entry.item.price || 0) * entry.quantity), 0);
  const formattedTotalPrice = lang === 'en' ? `${currency}${totalPrice.toFixed(2)}` : `${totalPrice.toLocaleString()} ${currency}`;
  
  messageText += translations[lang].whatsapp_total + `*${formattedTotalPrice}*`;
  
  const encodedText = encodeURIComponent(messageText);
  const url = `https://wa.me/${phoneNumber}?text=${encodedText}`;
  
  window.open(url, '_blank');
}
