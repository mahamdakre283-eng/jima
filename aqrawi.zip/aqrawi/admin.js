// admin.js

// State
let categories = [];
let items = [];
let editingItemId = null; // Tracks item being edited
let editingCategoryId = null; // Tracks category being edited

// DOM Elements
const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

// Forms & Inputs
const categoryForm = document.getElementById('categoryForm');
const itemForm = document.getElementById('itemForm');

// File Upload Previews
const catFile = document.getElementById('catFile');
const catPreview = document.getElementById('catPreview');
const catPreviewContainer = document.getElementById('catPreviewContainer');
const catUploadBox = document.getElementById('catUploadBox');

const itemFile = document.getElementById('itemFile');
const itemPreview = document.getElementById('itemPreview');
const itemPreviewContainer = document.getElementById('itemPreviewContainer');
const itemUploadBox = document.getElementById('itemUploadBox');

const itemCategorySelect = document.getElementById('itemCategorySelect');
const categoryListContainer = document.getElementById('categoryListContainer');
const itemListContainer = document.getElementById('itemListContainer');
const toastContainer = document.getElementById('toastContainer');

// New form buttons for edit mode (Items)
const itemFormCancelBtn = document.getElementById('itemFormCancelBtn');
const itemFormTitle = document.getElementById('itemFormTitle');
const itemFormSubmitBtn = document.getElementById('itemFormSubmitBtn');
const itemFormSubmitText = document.getElementById('itemFormSubmitText');
const itemFormSubmitIcon = document.getElementById('itemFormSubmitIcon');
const itemFormCard = document.getElementById('itemFormCard');

// New form buttons for edit mode (Categories)
const categoryFormCancelBtn = document.getElementById('categoryFormCancelBtn');
const categoryFormTitle = document.getElementById('categoryFormTitle');
const categoryFormSubmitBtn = document.getElementById('categoryFormSubmitBtn');
const categoryFormSubmitText = document.getElementById('categoryFormSubmitText');
const categoryFormSubmitIcon = document.getElementById('categoryFormSubmitIcon');
const categoryFormCard = document.getElementById('categoryFormCard');

// Register Listeners
function initAdmin() {
  setupTabs();
  setupFilePreviews();
  initSettingsTab();

  // Subscriptions
  subscribeCategories((data) => {
    categories = data;
    renderCategoriesSelect();
    renderCategoriesList();
    renderItemsList(); // Re-render items list because item category names might change
  });

  subscribeItems((data) => {
    items = data;
    renderItemsList();
  });

  // Submit Handlers
  categoryForm.addEventListener('submit', handleAddCategory);
  itemForm.addEventListener('submit', handleAddItem);
  itemFormCancelBtn.addEventListener('click', cancelItemEdit);
  categoryFormCancelBtn.addEventListener('click', cancelCategoryEdit);

  // Translate and render on custom event
  window.addEventListener('renderAdmin', () => {
    renderCategoriesSelect();
    renderCategoriesList();
    renderItemsList();
    updateFormLabelsTranslation();
  });
}

function checkLogin() {
  const isLogged = sessionStorage.getItem('admin_logged_in') === 'true';
  const loginSection = document.getElementById('adminLogin');
  const dashboardSection = document.getElementById('adminDashboard');

  if (isLogged) {
    if (loginSection) loginSection.style.display = 'none';
    if (dashboardSection) dashboardSection.style.display = 'block';
    initAdmin();
  } else {
    if (loginSection) loginSection.style.display = 'flex';
    if (dashboardSection) dashboardSection.style.display = 'none';
    setupLoginForm();
  }
}

function setupLoginForm() {
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = document.getElementById('loginEmail').value.trim();
      const password = document.getElementById('loginPassword').value.trim();
      const errorDiv = document.getElementById('loginError');

      if (email === 'mahamdakre53@gmail.com' && password === 'muhammadakre') {
        sessionStorage.setItem('admin_logged_in', 'true');
        const loginSection = document.getElementById('adminLogin');
        const dashboardSection = document.getElementById('adminDashboard');
        if (loginSection) loginSection.style.display = 'none';
        if (dashboardSection) dashboardSection.style.display = 'block';
        initAdmin();
      } else {
        if (errorDiv) {
          errorDiv.style.display = 'flex';
        }
      }
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', checkLogin);
} else {
  checkLogin();
}

// Toast Helper
function showToast(messageKey) {
  const lang = getSelectedLanguage();
  const message = translations[lang][messageKey] || messageKey;
  
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  toastContainer.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}



// Tab navigation setup
function setupTabs() {
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      
      tabButtons.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      
      btn.classList.add('active');
      document.getElementById(targetTab).classList.add('active');
      
      // If leaving items tab, cancel any pending edit to keep state clean
      if (targetTab !== 'itemsTab') {
        cancelItemEdit();
      }
      // If leaving categories tab, cancel any pending edit to keep state clean
      if (targetTab !== 'categoriesTab') {
        cancelCategoryEdit();
      }
    });
  });
}

// File Upload Preview Handling
function setupFilePreviews() {
  // Category image preview
  catFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        catPreview.src = event.target.result;
        catPreviewContainer.style.display = 'block';
      };
      reader.readAsDataURL(file);
    }
  });

  // Food item image preview
  itemFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        itemPreview.src = event.target.result;
        itemPreviewContainer.style.display = 'block';
      };
      reader.readAsDataURL(file);
    }
  });
}



// Translate form headers in edit mode dynamically
function updateFormLabelsTranslation() {
  const lang = getSelectedLanguage();
  if (editingItemId) {
    itemFormTitle.textContent = translations[lang].edit_item;
    itemFormSubmitText.textContent = translations[lang].update;
  } else {
    itemFormTitle.textContent = translations[lang].add_item;
    itemFormSubmitText.textContent = translations[lang].save;
  }

  if (editingCategoryId) {
    categoryFormTitle.textContent = translations[lang].edit_category;
    categoryFormSubmitText.textContent = translations[lang].update_category;
  } else {
    categoryFormTitle.textContent = translations[lang].add_category;
    categoryFormSubmitText.textContent = translations[lang].save;
  }
}

// --- Submit Actions ---

async function handleAddCategory(e) {
  e.preventDefault();
  
  const submitBtn = categoryForm.querySelector('.submit-btn');
  const originalText = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i> Loading...`;

  try {
    const file = catFile.files[0];
    let imageUrl = '';

    if (editingCategoryId) {
      // Edit Mode
      const currentCategory = categories.find(c => c.id === editingCategoryId);
      if (!currentCategory) throw new Error("Category not found");

      if (file) {
        imageUrl = await uploadImage(file);
      } else {
        imageUrl = currentCategory.image;
      }

      const categoryData = {
        name_en: document.getElementById('catNameEn').value.trim(),
        name_ku: document.getElementById('catNameKu').value.trim(),
        name_ar: document.getElementById('catNameAr').value.trim(),
        image: imageUrl
      };

      await updateCategory(editingCategoryId, categoryData);
      cancelCategoryEdit();
      showToast('toast_updated');
    } else {
      // Add Mode
      if (!file) throw new Error("Image required");
      imageUrl = await uploadImage(file);

      const categoryData = {
        name_en: document.getElementById('catNameEn').value.trim(),
        name_ku: document.getElementById('catNameKu').value.trim(),
        name_ar: document.getElementById('catNameAr').value.trim(),
        image: imageUrl
      };

      await addCategory(categoryData);

      // Reset Form
      categoryForm.reset();
      catPreviewContainer.style.display = 'none';
      catPreview.src = '';
      
      showToast('toast_saved');
    }
  } catch (error) {
    console.error("Error processing category:", error);
    alert("Error: " + error.message);
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = originalText;
  }
}

async function handleAddItem(e) {
  e.preventDefault();

  const originalText = itemFormSubmitBtn.innerHTML;
  itemFormSubmitBtn.disabled = true;
  itemFormSubmitBtn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i> Loading...`;

  try {
    const categoryId = itemCategorySelect.value;
    if (!categoryId) throw new Error("Category selection required");

    const file = itemFile.files[0];
    let imageUrl = '';

    if (editingItemId) {
      // Edit Mode
      const currentItem = items.find(i => i.id === editingItemId);
      if (!currentItem) throw new Error("Item not found");

      if (file) {
        // Upload new image
        imageUrl = await uploadImage(file);
      } else {
        // Keep old image
        imageUrl = currentItem.image;
      }

      const itemData = {
        category: categoryId,
        name_en: document.getElementById('itemNameEn').value.trim(),
        name_ku: document.getElementById('itemNameKu').value.trim(),
        name_ar: document.getElementById('itemNameAr').value.trim(),
        description_en: document.getElementById('itemDescEn').value.trim(),
        description_ku: document.getElementById('itemDescKu').value.trim(),
        description_ar: document.getElementById('itemDescAr').value.trim(),
        price: parseFloat(document.getElementById('itemPrice').value),
        image: imageUrl
      };

      await updateItem(editingItemId, itemData);
      
      cancelItemEdit(); // Reset form out of edit mode
      showToast('toast_updated');
    } else {
      // Add Mode
      if (!file) throw new Error("Image required");
      imageUrl = await uploadImage(file);

      const itemData = {
        category: categoryId,
        name_en: document.getElementById('itemNameEn').value.trim(),
        name_ku: document.getElementById('itemNameKu').value.trim(),
        name_ar: document.getElementById('itemNameAr').value.trim(),
        description_en: document.getElementById('itemDescEn').value.trim(),
        description_ku: document.getElementById('itemDescKu').value.trim(),
        description_ar: document.getElementById('itemDescAr').value.trim(),
        price: parseFloat(document.getElementById('itemPrice').value),
        image: imageUrl
      };

      await addItem(itemData);

      // Reset Form
      itemForm.reset();
      itemPreviewContainer.style.display = 'none';
      itemPreview.src = '';

      showToast('toast_saved');
    }
  } catch (error) {
    console.error("Error processing food item:", error);
    alert("Error: " + error.message);
  } finally {
    itemFormSubmitBtn.disabled = false;
    itemFormSubmitBtn.innerHTML = originalText;
  }
}

// Edit item trigger
window.editItemById = (id) => {
  const item = items.find(i => i.id === id);
  if (!item) return;

  editingItemId = id;
  const lang = getSelectedLanguage();

  // Populate fields
  itemCategorySelect.value = item.category;
  document.getElementById('itemNameEn').value = item.name_en || '';
  document.getElementById('itemNameKu').value = item.name_ku || '';
  document.getElementById('itemNameAr').value = item.name_ar || '';
  
  document.getElementById('itemDescEn').value = item.description_en || '';
  document.getElementById('itemDescKu').value = item.description_ku || '';
  document.getElementById('itemDescAr').value = item.description_ar || '';
  
  document.getElementById('itemPrice').value = item.price || 0;

  // Render preview image
  if (item.image) {
    itemPreview.src = item.image;
    itemPreviewContainer.style.display = 'block';
  } else {
    itemPreviewContainer.style.display = 'none';
    itemPreview.src = '';
  }

  // File is optional when editing
  itemFile.removeAttribute('required');

  // Change UI text
  itemFormTitle.textContent = translations[lang].edit_item;
  itemFormTitle.setAttribute('data-translate', 'edit_item');
  
  itemFormSubmitText.textContent = translations[lang].update;
  itemFormSubmitText.setAttribute('data-translate', 'update');
  itemFormSubmitIcon.className = 'fa-solid fa-pen-to-square';

  // Show Cancel Button
  itemFormCancelBtn.style.display = 'block';

  // Scroll to Form
  itemFormCard.scrollIntoView({ behavior: 'smooth' });
};

// Cancel edit mode
function cancelItemEdit() {
  editingItemId = null;
  const lang = getSelectedLanguage();

  // Reset form
  itemForm.reset();
  itemPreviewContainer.style.display = 'none';
  itemPreview.src = '';

  // Make file required again
  itemFile.setAttribute('required', 'true');

  // Restore UI text
  itemFormTitle.textContent = translations[lang].add_item;
  itemFormTitle.setAttribute('data-translate', 'add_item');
  
  itemFormSubmitText.textContent = translations[lang].save;
  itemFormSubmitText.setAttribute('data-translate', 'save');
  itemFormSubmitIcon.className = 'fa-solid fa-plus';

  // Hide Cancel Button
  itemFormCancelBtn.style.display = 'none';
}

window.editCategoryById = (id) => {
  const cat = categories.find(c => c.id === id);
  if (!cat) return;

  editingCategoryId = id;
  const lang = getSelectedLanguage();

  // Populate fields
  document.getElementById('catNameEn').value = cat.name_en || '';
  document.getElementById('catNameKu').value = cat.name_ku || '';
  document.getElementById('catNameAr').value = cat.name_ar || '';

  // Render preview image
  if (cat.image) {
    catPreview.src = cat.image;
    catPreviewContainer.style.display = 'block';
  } else {
    catPreviewContainer.style.display = 'none';
    catPreview.src = '';
  }

  // File is optional when editing
  catFile.removeAttribute('required');

  // Change UI text
  categoryFormTitle.textContent = translations[lang].edit_category || "Edit Category";
  categoryFormTitle.setAttribute('data-translate', 'edit_category');
  
  categoryFormSubmitText.textContent = translations[lang].update_category || "Update Category";
  categoryFormSubmitText.setAttribute('data-translate', 'update_category');
  categoryFormSubmitIcon.className = 'fa-solid fa-pen-to-square';

  // Show Cancel Button
  categoryFormCancelBtn.style.display = 'block';

  // Scroll to Form
  categoryFormCard.scrollIntoView({ behavior: 'smooth' });
};

function cancelCategoryEdit() {
  editingCategoryId = null;
  const lang = getSelectedLanguage();

  // Reset form
  categoryForm.reset();
  catPreviewContainer.style.display = 'none';
  catPreview.src = '';

  // Make file required again
  catFile.setAttribute('required', 'true');

  // Restore UI text
  categoryFormTitle.textContent = translations[lang].add_category || "Add New Category";
  categoryFormTitle.setAttribute('data-translate', 'add_category');
  
  categoryFormSubmitText.textContent = translations[lang].save || "Save / Add";
  categoryFormSubmitText.setAttribute('data-translate', 'save');
  categoryFormSubmitIcon.className = 'fa-solid fa-plus';

  // Hide Cancel Button
  categoryFormCancelBtn.style.display = 'none';
}

// --- Render Admin Lists ---

function renderCategoriesSelect() {
  const lang = getSelectedLanguage();
  const currentSelection = itemCategorySelect.value;
  
  let html = `<option value="" disabled selected>${translations[lang].select_category}</option>`;
  
  categories.forEach(cat => {
    const catName = cat[`name_${lang}`] || cat.name_en;
    html += `<option value="${cat.id}">${catName}</option>`;
  });

  itemCategorySelect.innerHTML = html;
  if (currentSelection) {
    itemCategorySelect.value = currentSelection;
  }
}

function renderCategoriesList() {
  const lang = getSelectedLanguage();
  
  if (categories.length === 0) {
    categoryListContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: var(--text-grey); padding: 20px;">No categories available</div>`;
    return;
  }

  categoryListContainer.innerHTML = categories.map(cat => {
    const catName = cat[`name_${lang}`] || cat.name_en;
    const imgUrl = cat.image || 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80';
    
    return `
      <div class="item-list-card">
        <img src="${imgUrl}" alt="${catName}" class="list-card-img" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80'">
        <div class="list-card-details">
          <div class="list-card-title">${catName}</div>
          <div class="list-card-sub">EN: ${cat.name_en} | KU: ${cat.name_ku}</div>
        </div>
        <div style="display: flex; gap: 8px;">
          <button class="submit-btn" style="padding: 10px; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;" onclick="editCategoryById('${cat.id}')">
            <i class="fa-solid fa-pen-to-square"></i>
          </button>
          <button class="danger-btn" style="padding: 10px; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;" onclick="deleteCategoryById('${cat.id}')">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </div>
    `;
  }).join('');
}

window.deleteCategoryById = async (id) => {
  const lang = getSelectedLanguage();
  const confText = lang === 'en' ? 'Delete category and all its items?' : 
                   lang === 'ku' ? 'ئەرێ تو یێ دڵنیای دڤێت ڤێ پشکێ و هەمی خوارنێن تێدا ژێببەی؟' : 
                   'هل أنت متأكد من حذف هذه الفئة وجميع وجباتها؟';
  if (confirm(confText)) {
    try {
      await deleteCategory(id);
      showToast('toast_deleted');
    } catch (e) {
      alert("Error deleting: " + e.message);
    }
  }
};

function renderItemsList() {
  const lang = getSelectedLanguage();
  const currency = translations[lang].currency;
  
  if (items.length === 0) {
    itemListContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: var(--text-grey); padding: 20px;">No items available</div>`;
    return;
  }

  itemListContainer.innerHTML = items.map(item => {
    const itemName = item[`name_${lang}`] || item.name_en;
    const cat = categories.find(c => c.id === item.category);
    const catName = cat ? (cat[`name_${lang}`] || cat.name_en) : 'Uncategorized';
    const price = parseFloat(item.price || 0);
    const imgUrl = item.image || 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80';
    
    const formattedPrice = lang === 'en' ? `${currency}${price.toFixed(2)}` : `${price.toLocaleString()} ${currency}`;

    return `
      <div class="item-list-card">
        <img src="${imgUrl}" alt="${itemName}" class="list-card-img" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80'">
        <div class="list-card-details">
          <div class="list-card-title">${itemName}</div>
          <div class="list-card-sub">${catName}</div>
          <div class="list-card-price">${formattedPrice}</div>
        </div>
        <div style="display: flex; gap: 8px;">
          <button class="submit-btn" style="padding: 10px; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;" onclick="editItemById('${item.id}')">
            <i class="fa-solid fa-pen-to-square"></i>
          </button>
          <button class="danger-btn" style="padding: 10px; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;" onclick="deleteItemById('${item.id}')">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </div>
    `;
  }).join('');
}

window.deleteItemById = async (id) => {
  const lang = getSelectedLanguage();
  const confText = lang === 'en' ? 'Delete this food item?' : 
                   lang === 'ku' ? 'ئەرێ تو یێ دڵنیای دڤێت ڤێ خوارنێ ژێببەی؟' : 
                   'هل أنت متأكد من حذف هذه الوجبة؟';
  if (confirm(confText)) {
    try {
      await deleteItem(id);
      showToast('toast_deleted');
    } catch (e) {
      alert("Error deleting: " + e.message);
    }
  }
};

// --- Settings management ---
let settings = {};

function initSettingsTab() {
  subscribeSettings((data) => {
    settings = data;
    
    // Set text fields
    document.getElementById('settingsNameEn').value = settings.restaurant_name_en || '';
    document.getElementById('settingsNameKu').value = settings.restaurant_name_ku || '';
    document.getElementById('settingsNameAr').value = settings.restaurant_name_ar || '';
    
    document.getElementById('settingsAddressEn').value = settings.address_en || '';
    document.getElementById('settingsAddressKu').value = settings.address_ku || '';
    document.getElementById('settingsAddressAr').value = settings.address_ar || '';
    
    // Set previews
    if (settings.logo) {
      document.getElementById('logoPreview').src = settings.logo;
      document.getElementById('logoPreviewContainer').style.display = 'block';
    }
    if (settings.bg_1) {
      document.getElementById('bg1Preview').src = settings.bg_1;
      document.getElementById('bg1PreviewContainer').style.display = 'block';
    }
    if (settings.bg_2) {
      document.getElementById('bg2Preview').src = settings.bg_2;
      document.getElementById('bg2PreviewContainer').style.display = 'block';
    }
    if (settings.bg_3) {
      document.getElementById('bg3Preview').src = settings.bg_3;
      document.getElementById('bg3PreviewContainer').style.display = 'block';
    }
  });

  setupSettingsPreviews();

  const settingsForm = document.getElementById('settingsForm');
  if (settingsForm) {
    settingsForm.addEventListener('submit', handleSaveSettings);
  }
}

function setupSettingsPreviews() {
  const fileInputs = [
    { fileId: 'logoFile', previewId: 'logoPreview', containerId: 'logoPreviewContainer' },
    { fileId: 'bg1File', previewId: 'bg1Preview', containerId: 'bg1PreviewContainer' },
    { fileId: 'bg2File', previewId: 'bg2Preview', containerId: 'bg2PreviewContainer' },
    { fileId: 'bg3File', previewId: 'bg3Preview', containerId: 'bg3PreviewContainer' }
  ];

  fileInputs.forEach(({ fileId, previewId, containerId }) => {
    const input = document.getElementById(fileId);
    const preview = document.getElementById(previewId);
    const container = document.getElementById(containerId);

    if (input && preview && container) {
      input.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            preview.src = event.target.result;
            container.style.display = 'block';
          };
          reader.readAsDataURL(file);
        }
      });
    }
  });
}

async function handleSaveSettings(e) {
  e.preventDefault();

  const submitBtn = document.getElementById('settingsFormSubmitBtn');
  const originalText = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i> Loading...`;

  try {
    const updatedSettings = { ...settings };

    // Read text field values
    updatedSettings.restaurant_name_en = document.getElementById('settingsNameEn').value.trim();
    updatedSettings.restaurant_name_ku = document.getElementById('settingsNameKu').value.trim();
    updatedSettings.restaurant_name_ar = document.getElementById('settingsNameAr').value.trim();
    
    updatedSettings.address_en = document.getElementById('settingsAddressEn').value.trim();
    updatedSettings.address_ku = document.getElementById('settingsAddressKu').value.trim();
    updatedSettings.address_ar = document.getElementById('settingsAddressAr').value.trim();

    const uploadIfSelected = async (fileId, keyName) => {
      const fileInput = document.getElementById(fileId);
      if (fileInput && fileInput.files && fileInput.files[0]) {
        const file = fileInput.files[0];
        const uploadedUrl = await uploadImage(file);
        updatedSettings[keyName] = uploadedUrl;
      }
    };

    await uploadIfSelected('logoFile', 'logo');
    await uploadIfSelected('bg1File', 'bg_1');
    await uploadIfSelected('bg2File', 'bg_2');
    await uploadIfSelected('bg3File', 'bg_3');

    await updateSettings(updatedSettings);

    // Clear inputs
    document.getElementById('logoFile').value = '';
    document.getElementById('bg1File').value = '';
    document.getElementById('bg2File').value = '';
    document.getElementById('bg3File').value = '';

    showToast('toast_saved');
  } catch (error) {
    console.error("Error saving settings:", error);
    alert("Error: " + error.message);
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = originalText;
  }
}
