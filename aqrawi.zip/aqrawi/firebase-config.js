// firebase-config.js
// Firebase configuration and database abstraction layer (non-module compatible version)

// Default placeholder categories to show if there is no data in LocalStorage
const DEFAULT_CATEGORIES = [
  {
    id: "cat_fast_food",
    name_en: "Fast Food",
    name_ku: "خوارنا خێرا",
    name_ar: "وجبات سريعة",
    image: "https://images.unsplash.com/photo-1561758033-d89a9ad46330?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: "cat_main_dishes",
    name_en: "Main Dishes",
    name_ku: "خوارنێن سەرەکی",
    name_ar: "الأطباق الرئيسية",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: "cat_drinks",
    name_en: "Drinks",
    name_ku: "ڤەخوارن",
    name_ar: "المشروبات",
    image: "https://images.unsplash.com/photo-1497534446932-c925b458314e?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: "cat_desserts",
    name_en: "Desserts",
    name_ku: "شیریناهی",
    name_ar: "الحلويات",
    image: "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=400&q=80"
  }
];

const DEFAULT_ITEMS = [
  {
    id: "item_burger",
    name_en: "Double Cheese Burger",
    name_ku: "دۆبڵ چیزبەرگر",
    name_ar: "دبل تشيز برغر",
    description_en: "Premium beef patty, double cheddar, special sauce, fresh lettuce.",
    description_ku: "گۆشتێ مانگێ یێ نایاب، پەنیڕێ چێدەر یێ دۆبڵ، سۆسا تایبەت، کاهوویا فرێش.",
    description_ar: "شريحة لحم بقري ممتازة، جبنة شيدر مزدوجة، صلصة خاصة، خس طازج.",
    price: 6.5,
    category: "cat_fast_food",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: "item_pizza",
    name_en: "Pepperoni Pizza",
    name_ku: "پیتزا پیپەرۆنی",
    name_ar: "بيتزا بيبيروني",
    description_en: "Italian mozzarella, premium pepperoni, rich tomato sauce.",
    description_ku: "پەنیڕێ مۆزارێلا یێ ئیتالی، پیپەرۆنی یا نایاب، سۆسا تەماتێ یا دەوڵەمەند.",
    description_ar: "جبنة موزاريلا إيطالية، بيبيروني ممتاز، صلصة طماطم غنية.",
    price: 8.0,
    category: "cat_fast_food",
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: "item_kabab",
    name_en: "Kurdish Kabab",
    name_ku: "کەبابێ کوردی",
    name_ar: "كباب كُردي",
    description_en: "Grilled lamb kebab, charcoal grilled, served with onion and bread.",
    description_ku: "کەبابێ بەرخێ یێ برژای، ل سەر خەلوزێ، دهێتە پێشکێشکرن دگەل پیڤاز و نانی.",
    description_ar: "كباب لحم ضأن مشوي على الفحم، يقدم مع البصل والخبز.",
    price: 12.0,
    category: "cat_main_dishes",
    image: "https://images.unsplash.com/photo-1603360946369-dc9bb6258143?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: "item_mojito",
    name_en: "Strawberry Mojito",
    name_ku: "مۆهیتۆیێ شیلکێ",
    name_ar: "موخيتو الفراولة",
    description_en: "Fresh strawberry, mint leaves, lime juice, sparkling water.",
    description_ku: "شیلکا فرێش، گەلایێن نەعنێ، ئاڤا لیمۆنێ، ئاڤا غازی.",
    description_ar: "فراولة طازجة، أوراق نعناع، عصير ليمون، مياه فوارة.",
    price: 3.5,
    category: "cat_drinks",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=400&q=80"
  }
];

const DEFAULT_SETTINGS = {
  logo: "images/logo.png",
  bg_1: "images/bg.png",
  bg_2: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
  bg_3: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1200&q=80",
  restaurant_name_en: "Akre Bistro",
  restaurant_name_ku: "ئاکرێ بیسترۆ",
  restaurant_name_ar: "بسترو عقرة",
  address_en: "Akre, 11 Aylol 2",
  address_ku: "ئاکرێ، ١١ی ئەیلوول ٢",
  address_ar: "عقرة، ١١ أيلول ٢"
};

// Initialize localStorage databases if empty
if (!localStorage.getItem("menu_categories_v2")) {
  localStorage.setItem("menu_categories_v2", JSON.stringify(DEFAULT_CATEGORIES));
}
if (!localStorage.getItem("menu_items_v2")) {
  localStorage.setItem("menu_items_v2", JSON.stringify(DEFAULT_ITEMS));
}
if (!localStorage.getItem("menu_settings_v2")) {
  localStorage.setItem("menu_settings_v2", JSON.stringify(DEFAULT_SETTINGS));
}

// Local listeners
let categoryListeners = [];
let itemListeners = [];
let settingsListeners = [];

// Firebase instances
let db = null;
let storage = null;
let firebaseActive = false;

// Firebase active subscriptions
let activeCategoryUnsubscribe = null;
let activeItemUnsubscribe = null;
let activeSettingsUnsubscribe = null;

function deactivateFirebase(reason) {
  if (!firebaseActive) return;
  console.warn("Deactivating Firebase compatibility mode. Falling back to Local Storage. Reason:", reason);
  firebaseActive = false;
  db = null;
  storage = null;
  
  // Unsubscribe active listeners
  if (activeCategoryUnsubscribe) {
    try { activeCategoryUnsubscribe(); } catch (e) {}
    activeCategoryUnsubscribe = null;
  }
  if (activeItemUnsubscribe) {
    try { activeItemUnsubscribe(); } catch (e) {}
    activeItemUnsubscribe = null;
  }
  if (activeSettingsUnsubscribe) {
    try { activeSettingsUnsubscribe(); } catch (e) {}
    activeSettingsUnsubscribe = null;
  }

  // Immediately notify listeners with the local storage fallback data
  categoryListeners.forEach(l => l(getLocalCategories()));
  itemListeners.forEach(l => l(getLocalItems()));
  settingsListeners.forEach(l => l(getLocalSettings()));
}

// Helper to dynamically load standard javascript files
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

const DEFAULT_FIREBASE_CONFIG = {
  apiKey: "AIzaSyCg-esUsG_QDJ-tkUG5Wzj_N-EBsPI5rFs",
  authDomain: "justme-e425d.firebaseapp.com",
  projectId: "justme-e425d",
  storageBucket: "justme-e425d.firebasestorage.app",
  messagingSenderId: "442806060999",
  appId: "1:442806060999:web:78d6dc5f7d6b20b705bbe2",
  measurementId: "G-1LLYVVGFPX"
};

// Asynchronously initialize Firebase if configuration exists
async function initFirebase() {
  let config = DEFAULT_FIREBASE_CONFIG;
  const storedConfig = localStorage.getItem("firebase_config");
  if (storedConfig) {
    try {
      config = JSON.parse(storedConfig);
    } catch (error) {
      console.error("Failed to parse stored firebase_config:", error);
    }
  }

  if (config && config.apiKey && config.projectId) {
    try {
      // Load Firebase compatibility scripts
      await loadScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js");
      await loadScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore-compat.js");
      await loadScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-storage-compat.js");

      const app = firebase.initializeApp(config);
      db = firebase.firestore(app);
      storage = firebase.storage(app);
      firebaseActive = true;
      console.log("Firebase initialized successfully via compatibility SDK.");

      // Upgrade active listeners to Firebase
      attachFirebaseListeners();
    } catch (error) {
      console.error("Failed to initialize Firebase:", error);
    }
  }
}

// Run firebase initialization
initFirebase();

function attachFirebaseListeners() {
  if (firebaseActive && db) {
    // Categories Subscription
    if (activeCategoryUnsubscribe) activeCategoryUnsubscribe();
    activeCategoryUnsubscribe = db.collection("categories").orderBy("name_en").onSnapshot((snapshot) => {
      const categoriesData = [];
      snapshot.forEach((doc) => {
        categoriesData.push({ id: doc.id, ...doc.data() });
      });
      categoryListeners.forEach(l => l(categoriesData));
    }, (err) => {
      console.error("Firebase categories subscription error:", err);
      deactivateFirebase(err);
    });

    // Items Subscription
    if (activeItemUnsubscribe) activeItemUnsubscribe();
    activeItemUnsubscribe = db.collection("items").orderBy("name_en").onSnapshot((snapshot) => {
      const itemsData = [];
      snapshot.forEach((doc) => {
        itemsData.push({ id: doc.id, ...doc.data() });
      });
      itemListeners.forEach(l => l(itemsData));
    }, (err) => {
      console.error("Firebase items subscription error:", err);
      deactivateFirebase(err);
    });

    // Settings Subscription
    if (activeSettingsUnsubscribe) activeSettingsUnsubscribe();
    activeSettingsUnsubscribe = db.collection("settings").doc("app_settings").onSnapshot((doc) => {
      if (doc.exists) {
        const settingsData = doc.data();
        settingsListeners.forEach(l => l(settingsData));
      } else {
        db.collection("settings").doc("app_settings").set(DEFAULT_SETTINGS);
        settingsListeners.forEach(l => l(DEFAULT_SETTINGS));
      }
    }, (err) => {
      console.error("Firebase settings subscription error:", err);
      deactivateFirebase(err);
    });
  }
}

// --- Subscription Getters ---

function subscribeCategories(callback) {
  categoryListeners.push(callback);

  if (firebaseActive && db) {
    attachFirebaseListeners();
  } else {
    callback(getLocalCategories());
  }

  return () => {
    categoryListeners = categoryListeners.filter(l => l !== callback);
  };
}

function subscribeItems(callback) {
  itemListeners.push(callback);

  if (firebaseActive && db) {
    attachFirebaseListeners();
  } else {
    callback(getLocalItems());
  }

  return () => {
    itemListeners = itemListeners.filter(l => l !== callback);
  };
}

function subscribeSettings(callback) {
  settingsListeners.push(callback);

  if (firebaseActive && db) {
    attachFirebaseListeners();
  } else {
    callback(getLocalSettings());
  }

  return () => {
    settingsListeners = settingsListeners.filter(l => l !== callback);
  };
}

// --- Helper Local Storage Getters/Setters ---

function getLocalCategories() {
  try {
    const raw = localStorage.getItem("menu_categories_v2");
    if (!raw) return DEFAULT_CATEGORIES;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEFAULT_CATEGORIES;
  } catch (e) {
    console.error("Failed to load local categories:", e);
    return DEFAULT_CATEGORIES;
  }
}

function setLocalCategories(categories) {
  localStorage.setItem("menu_categories_v2", JSON.stringify(categories));
  categoryListeners.forEach(l => l(categories));
}

function getLocalItems() {
  try {
    const raw = localStorage.getItem("menu_items_v2");
    if (!raw) return DEFAULT_ITEMS;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEFAULT_ITEMS;
  } catch (e) {
    console.error("Failed to load local items:", e);
    return DEFAULT_ITEMS;
  }
}

function setLocalItems(items) {
  localStorage.setItem("menu_items_v2", JSON.stringify(items));
  itemListeners.forEach(l => l(items));
}

function getLocalSettings() {
  try {
    const raw = localStorage.getItem("menu_settings_v2");
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return parsed && parsed.logo ? { ...DEFAULT_SETTINGS, ...parsed } : DEFAULT_SETTINGS;
  } catch (e) {
    console.error("Failed to load local settings:", e);
    return DEFAULT_SETTINGS;
  }
}

function setLocalSettings(settings) {
  localStorage.setItem("menu_settings_v2", JSON.stringify(settings));
  settingsListeners.forEach(l => l(settings));
}

async function updateSettings(settingsData) {
  if (firebaseActive && db) {
    try {
      await db.collection("settings").doc("app_settings").set(settingsData, { merge: true });
      return;
    } catch (e) {
      console.warn("Firebase updateSettings failed, falling back to LocalStorage:", e);
      deactivateFirebase(e);
    }
  }
  const settings = { ...getLocalSettings(), ...settingsData };
  setLocalSettings(settings);
}

// --- Write Operations ---

async function addCategory(categoryData) {
  if (firebaseActive && db) {
    try {
      const docRef = await db.collection("categories").add(categoryData);
      return docRef.id;
    } catch (e) {
      console.warn("Firebase addCategory failed, falling back to LocalStorage:", e);
      deactivateFirebase(e);
    }
  }
  const categories = getLocalCategories();
  const newCategory = {
    id: "cat_" + Date.now(),
    ...categoryData
  };
  categories.push(newCategory);
  setLocalCategories(categories);
  return newCategory.id;
}

async function updateCategory(id, categoryData) {
  if (firebaseActive && db) {
    try {
      await db.collection("categories").doc(id).set(categoryData, { merge: true });
      return;
    } catch (e) {
      console.warn("Firebase updateCategory failed, falling back to LocalStorage:", e);
      deactivateFirebase(e);
    }
  }
  let categories = getLocalCategories();
  categories = categories.map(c => c.id === id ? { ...c, ...categoryData } : c);
  setLocalCategories(categories);
}

async function deleteCategory(id) {
  if (firebaseActive && db) {
    try {
      await db.collection("categories").doc(id).delete();

      // Cascade delete items of this category in Firebase
      try {
        const itemsSnapshot = await db.collection("items").where("category", "==", id).get();
        const batch = db.batch();
        itemsSnapshot.forEach((doc) => {
          batch.delete(doc.ref);
        });
        await batch.commit();
      } catch (e) {
        console.error("Cascade deletion failed on Firebase:", e);
      }
      return;
    } catch (e) {
      console.warn("Firebase deleteCategory failed, falling back to LocalStorage:", e);
      deactivateFirebase(e);
    }
  }
  let categories = getLocalCategories();
  categories = categories.filter(c => c.id !== id);
  setLocalCategories(categories);

  // Cascade delete items of this category locally
  let items = getLocalItems();
  items = items.filter(item => item.category !== id);
  setLocalItems(items);
}

async function addItem(itemData) {
  if (firebaseActive && db) {
    try {
      const docRef = await db.collection("items").add(itemData);
      return docRef.id;
    } catch (e) {
      console.warn("Firebase addItem failed, falling back to LocalStorage:", e);
      deactivateFirebase(e);
    }
  }
  const items = getLocalItems();
  const newItem = {
    id: "item_" + Date.now(),
    ...itemData
  };
  items.push(newItem);
  setLocalItems(items);
  return newItem.id;
}

async function deleteItem(id) {
  if (firebaseActive && db) {
    try {
      await db.collection("items").doc(id).delete();
      return;
    } catch (e) {
      console.warn("Firebase deleteItem failed, falling back to LocalStorage:", e);
      deactivateFirebase(e);
    }
  }
  let items = getLocalItems();
  items = items.filter(i => i.id !== id);
  setLocalItems(items);
}

async function updateItem(id, itemData) {
  if (firebaseActive && db) {
    try {
      await db.collection("items").doc(id).set(itemData, { merge: true });
      return;
    } catch (e) {
      console.warn("Firebase updateItem failed, falling back to LocalStorage:", e);
      deactivateFirebase(e);
    }
  }
  let items = getLocalItems();
  items = items.map(i => i.id === id ? { ...i, ...itemData } : i);
  setLocalItems(items);
}

// --- Image Upload Helpers ---

async function uploadImage(file) {
  const compressedBase64 = await compressImage(file, 600, 600);

  if (firebaseActive && storage) {
    try {
      const filename = `images/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
      const storageRef = storage.ref().child(filename);
      const snapshot = await storageRef.putString(compressedBase64, 'data_url');
      const downloadURL = await snapshot.ref.getDownloadURL();
      return downloadURL;
    } catch (error) {
      console.error("Failed to upload to Firebase Storage, falling back to Base64:", error);
      return compressedBase64;
    }
  }

  return compressedBase64;
}

function compressImage(file, maxWidth, maxHeight) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);

        resolve(canvas.toDataURL("image/jpeg", 0.75));
      };
    };
    reader.onerror = (error) => reject(error);
  });
}

// Cross-tab synchronization listener for LocalStorage updates
window.addEventListener('storage', (e) => {
  if (e.key === 'menu_categories_v2') {
    try {
      const updatedCategories = JSON.parse(e.newValue || '[]');
      categoryListeners.forEach(l => l(updatedCategories));
    } catch (err) {
      console.error("Failed to parse cross-tab categories sync:", err);
    }
  }
  if (e.key === 'menu_items_v2') {
    try {
      const updatedItems = JSON.parse(e.newValue || '[]');
      itemListeners.forEach(l => l(updatedItems));
    } catch (err) {
      console.error("Failed to parse cross-tab items sync:", err);
    }
  }
  if (e.key === 'menu_settings_v2') {
    try {
      const updatedSettings = JSON.parse(e.newValue || '{}');
      settingsListeners.forEach(l => l(updatedSettings));
    } catch (err) {
      console.error("Failed to parse cross-tab settings sync:", err);
    }
  }
});
