@echo off
title Akre Bistro Launcher
echo =========================================
echo  Starting Akre Bistro Local Server...
echo =========================================
echo.

:: Get node path from AppData
set "NODE_PATH=C:\Users\All Aqrawii28\AppData\Local\ms-playwright-go\1.57.0\node.exe"

if exist "%NODE_PATH%" (
    echo [INFO] Found Node.js executable.
    start "Akre Bistro Server" /min "%NODE_PATH%" "%~dp0server.js"
) else (
    echo [INFO] Looking for system node...
    where node >nul 2>nul
    if %errorlevel% equ 0 (
        start "Akre Bistro Server" /min node "%~dp0server.js"
    ) else (
        echo [ERROR] Node.js is not found on your system!
        echo Please contact support or install Node.js from https://nodejs.org/
        pause
        exit /b
    )
)

echo.
echo [INFO] Waiting for server to start...
timeout /t 2 /nobreak >nul

echo [INFO] Opening Akre Bistro in Microsoft Edge...
start microsoft-edge:http://localhost:8085/index.html

echo.
echo =========================================
echo  Akre Bistro is running!
echo  You can close this window now.
echo =========================================
timeout /t 3 >nul
exit
